﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Data.SqlClient;

namespace ITalk
{
    public partial class Form1 : Form
    {
        Socket sck;
        EndPoint epLocal, epRemote;
        byte[] buffer;

        Bitmap ICON = new Bitmap(Properties.Resources.ITLogo1);

        DateTime Time;
        string USERNAME;
        string user;
        string USERCODE;
        string prevMessID = "";
        string IP;
        string RemoteIP;
        string localPort;
        string remotePort;
        string RemoteName;

        bool sending = false;

        bool active;
        public Form1()
        {
            InitializeComponent();
            //label2.Text = "false";

            sck = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            sck.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            IP = GetLocalIP();
            //RemoteIP = GetLocalIP();
            //label2.Text = IP;
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            setup();
        }

        void setup()
        {
            StreamReader sr = new StreamReader($"{Directory.GetCurrentDirectory()}\\Setup.txt");
            USERCODE = sr.ReadLine();
            if (USERCODE == "new")
            {
                sr.Close();
                NewUserPanel.Top = 273;
                newUserSetup();
                return;
            }
            else
            {
                USERNAME = sr.ReadLine();
                IP = sr.ReadLine();
                localPort = sr.ReadLine();
                sr.Close();
                RefreshFriends();
            }
        }

        void newUserSetup()
        {
            NewUserPanel.Top = 0;
        }

        private string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach(IPAddress ip in host.AddressList)
            {
                if(ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        }

        void sendMessage(string MESSAGE)
        {
            if (sending)
            {
                ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
                byte[] sendingMessage = new byte[1500];
                sendingMessage = aSCIIEncoding.GetBytes(MessageTyper.Text);
                sck.Send(sendingMessage);
            }

            int PrevBott = 0;
            foreach (Control ctrl in Main.Controls)
            {
                if(ctrl.Tag != null)
                {
                    if (ctrl.Tag.ToString() == prevMessID)
                    {
                        //label2.Text = "true";
                    PrevBott = ctrl.Bottom;
                    }
                }
            }
            Time = DateTime.Now;
            var messagebox = new Panel
            {
                Width = Main.Width - 1,
                Height = 1,
                Left = 0,
                AutoSize = true,
                ForeColor = Color.Lime
            };
            Main.Controls.Add(messagebox);
            var name = new Label
            {
                Text = user,
                Font = new Font("Franklin Gothic Medium Cond", 15)
            };
            messagebox.Controls.Add(name);
            name.Top = 0;
            var timestamp = new Label
            {
                Text = Time.ToString(),
                ForeColor = Color.FromArgb(100, 100, 100)
            };
            messagebox.Controls.Add(timestamp);
            timestamp.Left = name.Right;
            timestamp.Top = 0;
            var message = new Label
            {
                Text = MESSAGE,
                ForeColor = Color.White,
                AutoSize = true
            };
            messagebox.Controls.Add(message);
            message.Top = name.Bottom;
            message.Left = 0;
            messagebox.Visible = true;
            messagebox.TabIndex = 0;
            messagebox.Height = message.Bottom + 10;
            if(PrevBott != 0)
            {
                messagebox.Top = PrevBott;
            }
            //label1.Text = PrevBott.ToString();

            pickID(messagebox, name, timestamp);

            prevMessID = messagebox.Tag.ToString();

            MessageTyper.ResetText();

            messagebox.MouseEnter += MessageHovered;
            messagebox.MouseLeave += MessageLeft;

            //int x = 0;
            /*foreach(Control control in Main.Controls)
            {
                var temp = new Label
                {
                    Text = control.Name,
                    Left = 50,
                    Top = x
                };
                Main.Controls.Add(temp);
                x++;
            }*/
        }

        void pickID(Panel messagebox, Label name, Label timestamp)
        {
            bool uID = true;
            Random rand = new Random();
            messagebox.Tag = $"{name.Text}{timestamp.Text}{rand.Next()}";
            foreach(Control ctrl in Controls)
            {
                if(ctrl.Tag == messagebox.Tag)
                {
                    uID = false;
                    break;
                }
            }
            if (!uID)
            {
                pickID(messagebox, name, timestamp);
            }
            //label2.Text = messagebox.Tag.ToString();
        }

        private void PrepareMessage(object sender, EventArgs e)
        {
            /*string MESSAGE = MessageTyper.Text;
            user = USERNAME;
            sending = true;
            sendMessage(MESSAGE);
            sending = false;
            MessageTyper.Text = "";*/

           ASCIIEncoding aEncoding = new ASCIIEncoding();
            byte[] sendingMessage = new byte[1500];
            sendingMessage = aEncoding.GetBytes(MessageTyper.Text);

            sck.Send(sendingMessage);
            listBox1.Items.Add("Me: " + MessageTyper.Text);
            MessageTyper.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string MESSAGE = "hi";
            user = "Friend";
        }

        private void EnterPressed(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter && Control.ModifierKeys != Keys.Shift)
            {
                string MESSAGE = MessageTyper.Text;
                ASCIIEncoding aEncoding = new ASCIIEncoding();
                byte[] sendingMessage = new byte[1500];
                sendingMessage = aEncoding.GetBytes(MessageTyper.Text);

                sck.Send(sendingMessage);
                listBox1.Items.Add("Me: " + MessageTyper.Text);
                MessageTyper.Text = "";

                listBox1.Focus();
                listBox1.SelectedIndex = listBox1.Items.Count - 1;
                listBox1.SelectedIndex = -1;
            }
        }

        private void MessageHovered(object sender, EventArgs e)
        {
            /* Panel thing = sender;
             thing.Tag = "focused";*/
            Panel pnl = (Panel)sender;
            pnl.Name = "focused";
            label1.Text = $"{pnl} is Hovered!";
        }

        private void BoxHovered(object sender, EventArgs e)
        {
            /* Panel thing = sender;
             thing.Tag = "focused";*/
            Panel pnl = (Panel)sender;
            pnl.Tag = "focused";
            //label1.Text = $"{pnl} is Hovered!";
        }

        private void BoxLeft(object sender, EventArgs e)
        {
            Panel pnl = (Panel)sender;
            pnl.Tag = "notfocused";
        }

        private void MessageLeft(object sender, EventArgs e)
        {
            Panel pnl = (Panel)sender;
            pnl.Name = "";
        }

        private void ResizeTextBox(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                epLocal = new IPEndPoint(IPAddress.Parse(IP), Convert.ToInt32(localPort));
                sck.Bind(epLocal);
                epRemote = new IPEndPoint(IPAddress.Parse(RemoteIP), Convert.ToInt32(remotePort));
                sck.Connect(epRemote);
                buffer = new byte[1500];
                sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(MessageCallBack), buffer);
            }
            catch(Exception ex) {
                MessageBox.Show(ex.ToString())
;            }
        }

        private void ImageMessageCallBack(IAsyncResult aResult)
        {
            byte[] receivedData = new byte[1500];
            receivedData = (byte[])aResult.AsyncState;
            ASCIIEncoding aEncoding = new ASCIIEncoding();
            string receivedMessage = aEncoding.GetString(receivedData);

            var imageMemoryStream = new MemoryStream(receivedData);
            Image imgFromStream = Image.FromStream(imageMemoryStream);

            PictureBox pictureSent = new PictureBox
            {
                Width = 100,
                Height = 50,
                BackgroundImage = imgFromStream,
                BackgroundImageLayout = ImageLayout.Stretch
            };

            listBox1.Items.Add($"{RemoteName}: {pictureSent}");
            if (!active)
            {
                NotificationBox.Icon = new Icon("ITLogo.ico");
                NotificationBox.BalloonTipTitle = "ITalk";
                NotificationBox.BalloonTipText = $"{pictureSent}";
                NotificationBox.ShowBalloonTip(100);
            }

            listBox1.Focus();
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
            listBox1.SelectedIndex = -1;
        }

        private void MessageCallBack(IAsyncResult aResult)
        {
            byte[] receivedData = new byte[1500];
            receivedData = (byte[])aResult.AsyncState;
            ASCIIEncoding aEncoding = new ASCIIEncoding();
            string receivedMessage = aEncoding.GetString(receivedData);

            listBox1.Items.Add($"{RemoteName}: {receivedData}");
            if(!active)
            {
                NotificationBox.Icon = new Icon("ITLogo.ico");
                NotificationBox.BalloonTipTitle = "ITalk";
                NotificationBox.BalloonTipText = $"{receivedMessage}";
                NotificationBox.ShowBalloonTip(100);
            }

            listBox1.Focus();
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
            listBox1.SelectedIndex = -1;

            /*int PrevBott = 0;
            foreach (Control ctrl in Main.Controls)
            {
                if (ctrl.Tag != null)
                {
                    if (ctrl.Tag.ToString() == prevMessID)
                    {
                        //label2.Text = "true";
                        PrevBott = ctrl.Bottom;
                    }
                }
            }
            Time = DateTime.Now;
            var messagebox = new Panel
            {
                Width = Main.Width - 1,
                Height = 1,
                Left = 0,
                AutoSize = true,
                ForeColor = Color.Lime
            };
            Main.Controls.Add(messagebox);
            var name = new Label
            {
                Text = RemoteName,
                Font = new Font("Franklin Gothic Medium Cond", 15)
            };
            messagebox.Controls.Add(name);
            name.Top = 0;
            var timestamp = new Label
            {
                Text = Time.ToString(),
                ForeColor = Color.FromArgb(100, 100, 100)
            };
            messagebox.Controls.Add(timestamp);
            timestamp.Left = name.Right;
            timestamp.Top = 0;
            var message = new Label
            {
                Text = receivedMessage,
                ForeColor = Color.White,
                AutoSize = true
            };
            messagebox.Controls.Add(message);
            message.Top = name.Bottom;
            message.Left = 0;
            messagebox.Visible = true;
            messagebox.TabIndex = 0;
            messagebox.Height = message.Bottom + 10;
            if (PrevBott != 0)
            {
                messagebox.Top = PrevBott;
            }
            //label1.Text = PrevBott.ToString();

            pickID(messagebox, name, timestamp);

            prevMessID = messagebox.Tag.ToString();

            messagebox.MouseEnter += MessageHovered;
            messagebox.MouseLeave += MessageLeft;*/

            buffer = new byte[1500];
            sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(MessageCallBack), buffer);
        }

        private void AddFriendButton_Click(object sender, EventArgs e)
        {
            addFriendPanel.Top = 159;
        }

        private void ConnectFriendButton_Click(object sender, EventArgs e)
        {
            string code = FriendCodeBox.Text;
            FriendCodeBox.Text = "";
            string[] arr = code.Split('#');
            string name = arr[0];
            string ip = arr[1];
            string[] ipArray = ip.Split('.');
            for (int x = 0; x < ipArray.Length - 1; x++)
            {
                var temp = Convert.ToInt32(ipArray[x]) - 5;
                ipArray[x] = temp.ToString();
            }
            ip = String.Join(".", ipArray);

            string path = Directory.GetCurrentDirectory();

            StreamWriter sw = new StreamWriter($"{path}\\Friends\\{name}.txt");
            sw.WriteLine(name);
            sw.WriteLine(ip);
            sw.Write(arr[2]);
            sw.Close();
            MessageBox.Show("Friend Added Sucessfuly");
            addFriendPanel.Top = 1590;
            RefreshFriends();
        }

        private void focusControl_Tick(object sender, EventArgs e)
        {
            foreach(Control ctrl in Menu.Controls)
            {
                if (ctrl.Tag == "focused")
                {
                    ctrl.BackColor = Color.FromArgb(80, 80, 80);
                }
                else if(ctrl.Tag == "notfocused")
                {
                    ctrl.BackColor = Color.FromArgb(20, 20, 20);
                }
            }
        }

        void RefreshFriends()
        {
            string PATH = $"{Directory.GetCurrentDirectory()}\\Friends\\";
            string[] filesPresent = Directory.GetFiles(PATH, "*.txt");
            label2.Text = String.Join(" ", filesPresent);
            //label2.Text = filesPresent[0];
            int y = 0;
            for(int x = 0; x < filesPresent.Length; x++)
            {
                label2.Text = filesPresent[x];
                string[] temp = filesPresent[x].Split('\\');
                string temp2 = temp[temp.Length - 1];
                string[] temp3 = temp2.Split('.');
                label2.Text = temp3[0];
                Panel person = new Panel {
                    Width = 50,
                    Height = 50,
                    BackColor = Color.FromArgb(20, 20, 20),
                    Name = temp3[0],
                    Top = y + 10
                };
                Menu.Controls.Add(person);
                person.Left = 0 + (person.Width / 2);
                Label lbl = new Label
                {
                    Text = person.Name,
                    ForeColor = Color.White
                };
                person.Controls.Add(lbl);
                y += 60;
                person.Click += ConnectToFriend;
                label2.Text = person.Name;

                person.MouseEnter += BoxHovered;
                person.MouseLeave += BoxLeft;
                //label2.Text = person.Left.ToString();
                //label2.Text = temp2;

            }
            /*int ba = 0;
            foreach(Control ctrl in Main.Controls)
            {
                Label lbl = new Label
                {
                    Text = ctrl.Name,
                    Left = 0,
                    Top = ba
                };
                Main.Controls.Add(lbl);
                ba += 10;
            }*/
            //MessageBox.Show("Friends Refreshed");
        }

        private void MakeUser_Click(object sender, EventArgs e)
        {
            if(AddUsersNameBox.Text != string.Empty && AddUsersPortBox.Text != string.Empty)
            {
                string username = AddUsersNameBox.Text;
                string ip = GetLocalIP();
                string port = AddUsersPortBox.Text;

                string code;
                string[] temp = ip.Split('.');
                for (int x = 0; x < temp.Length - 1; x++)
                {
                    var y = Convert.ToInt32(temp[x]) + 5;
                    temp[x] = y.ToString(); ;
                }
                code = $"{username}#{String.Join(".", temp)}#{port}";

                StreamWriter sw = new StreamWriter($"{Directory.GetCurrentDirectory()}\\Setup.txt");
                sw.WriteLine(code);
                sw.WriteLine(username);
                sw.WriteLine(ip);
                sw.Write(port);
                sw.Close();

                NewUserPanel.Top = 1000;
                setup();
            }
        }

        private void ToggleCode_Click(object sender, EventArgs e)
        {
            MessageBox.Show(USERCODE);
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            active = true;
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {
            active = false;
        }

        private void CancelButton1_Click(object sender, EventArgs e)
        {
            addFriendPanel.Top = 1590;
            FriendCodeBox.Text = "";
        }

        private void NotificationBox_MouseClick(object sender, MouseEventArgs e)
        {
            Activate();
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
            listBox1.SelectedIndex = -1;
        }

        private void SignInButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=MC-RM215-1427-D\\SQLEXPRESS;Initial Catalog=ITalkAccounts;User ID=sa;Password=***********");
            SqlDataAdapter sda = new SqlDataAdapter($"SELECT * FROM AccountInfo", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            SignInUsername.Text = dt.Rows[0][0].ToString();
            SignInPassword.Text = dt.Rows[0][1].ToString();
            for(int x  = 0; x < dt.Rows.Count; x++)
            {
                if(SignInUsername.Text == dt.Rows[x][0].ToString())
                {
                    if (SignInPassword.Text == dt.Rows[x][1].ToString())
                    {
                        USERNAME = SignInUsername.Text;
                        IP = GetLocalIP();
                        localPort = "80";
                        RefreshFriends();
                    }
                }
            }
        }

        private void UploadImageButton_Click(object sender, EventArgs e)
        {
            var filepath = string.Empty;
            var fileContent = string.Empty;
            OpenFileDialog opf = new OpenFileDialog();
            opf.InitialDirectory = "C:\\";
            opf.Filter = "Image Files (*.jpg)|*.jpg";
            opf.FilterIndex = 2;
            if(opf.ShowDialog() == DialogResult.OK)
            {
                filepath = opf.FileName;
                var fileStream = opf.OpenFile();
                using(StreamReader reader = new StreamReader(fileStream))
                {
                    fileContent = reader.ReadToEnd();
                }

                Image image = Image.FromFile(filepath);
                var ms = new MemoryStream();
                image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                var bytes = ms.ToArray();

                var imageMemoryStream = new MemoryStream(bytes);
                Image imgFromStream = Image.FromStream(imageMemoryStream);

                //sck.EndReceiveFrom(MessageCallBack, epLocal);
                //sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(ImageMessageCallBack), buffer);

                ASCIIEncoding aEncoding = new ASCIIEncoding();
                byte[] sendingMessage = new byte[1500];
                char[] charFromByte = new char[bytes.Length];
                for(int x = 0; x < (charFromByte.Length - 1); x++)
                {
                    charFromByte[x] = Convert.ToChar(bytes[x]);
                }
                sendingMessage = aEncoding.GetBytes(charFromByte);

                PictureBox pictureSent = new PictureBox
                {
                    Width = 100,
                    Height = 50,
                    BackgroundImage = imgFromStream,
                    BackgroundImageLayout = ImageLayout.Stretch
                };
                this.Controls.Add(pictureSent);
                pictureSent.Left = 0;
                pictureSent.Top = 0;

                sck.Send(sendingMessage);
                listBox1.Items.Add("Me: " + pictureSent);
                MessageTyper.Text = "";

                listBox1.Focus();
                listBox1.SelectedIndex = listBox1.Items.Count - 1;
                listBox1.SelectedIndex = -1;
            }
        }

        private void ConnectToFriend(object sender, EventArgs e)
        {
            Panel pt = (Panel)sender;
            string PATH = $"{Directory.GetCurrentDirectory()}\\Friends\\" + pt.Name + ".txt";
            StreamReader sr = new StreamReader(PATH);
            RemoteName = sr.ReadLine();
            RemoteIP = sr.ReadLine();
            remotePort = sr.ReadLine();

            epLocal = new IPEndPoint(IPAddress.Parse(IP), Convert.ToInt32(localPort));
            sck.Bind(epLocal);
            epRemote = new IPEndPoint(IPAddress.Parse(RemoteIP), Convert.ToInt32(remotePort));
            sck.Connect(epRemote);
            buffer = new byte[1500];
            sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(MessageCallBack), buffer);

            listBox1.Items.Add($"~~SYSTEM~~: Connected to[{RemoteName}]");
        }
    }
}
