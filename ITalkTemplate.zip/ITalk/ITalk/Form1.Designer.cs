﻿
namespace ITalk
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Menu = new System.Windows.Forms.Panel();
            this.AddFriendButton = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.sendButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Main = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.MessageTyper = new System.Windows.Forms.RichTextBox();
            this.focusControl = new System.Windows.Forms.Timer(this.components);
            this.addFriendPanel = new System.Windows.Forms.Panel();
            this.CancelButton1 = new System.Windows.Forms.Button();
            this.ConnectFriendButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.FriendCodeBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.NewUserPanel = new System.Windows.Forms.Panel();
            this.MakeUser = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.AddUsersPortBox = new System.Windows.Forms.TextBox();
            this.AddUsersNameBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ToggleCode = new System.Windows.Forms.Button();
            this.NotificationBox = new System.Windows.Forms.NotifyIcon(this.components);
            this.SignInPanel = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.SignInUsername = new System.Windows.Forms.TextBox();
            this.SignInPassword = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SignInButton = new System.Windows.Forms.Button();
            this.Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddFriendButton)).BeginInit();
            this.Main.SuspendLayout();
            this.addFriendPanel.SuspendLayout();
            this.NewUserPanel.SuspendLayout();
            this.SignInPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Menu
            // 
            this.Menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Menu.Controls.Add(this.AddFriendButton);
            this.Menu.Controls.Add(this.button2);
            this.Menu.Controls.Add(this.button1);
            this.Menu.Dock = System.Windows.Forms.DockStyle.Right;
            this.Menu.Location = new System.Drawing.Point(1065, 0);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(91, 750);
            this.Menu.TabIndex = 0;
            // 
            // AddFriendButton
            // 
            this.AddFriendButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.AddFriendButton.BackColor = System.Drawing.Color.Transparent;
            this.AddFriendButton.BackgroundImage = global::ITalk.Properties.Resources.PlusSign;
            this.AddFriendButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AddFriendButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddFriendButton.Location = new System.Drawing.Point(15, 680);
            this.AddFriendButton.Name = "AddFriendButton";
            this.AddFriendButton.Size = new System.Drawing.Size(65, 65);
            this.AddFriendButton.TabIndex = 4;
            this.AddFriendButton.TabStop = false;
            this.AddFriendButton.Click += new System.EventHandler(this.AddFriendButton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(13, 652);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 605);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "friend Message";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // sendButton
            // 
            this.sendButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.sendButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.sendButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sendButton.ForeColor = System.Drawing.Color.White;
            this.sendButton.Location = new System.Drawing.Point(796, 711);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(75, 23);
            this.sendButton.TabIndex = 4;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = false;
            this.sendButton.Click += new System.EventHandler(this.PrepareMessage);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(477, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(477, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // Main
            // 
            this.Main.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Main.AutoScroll = true;
            this.Main.Controls.Add(this.listBox1);
            this.Main.Controls.Add(this.label2);
            this.Main.Controls.Add(this.label1);
            this.Main.Location = new System.Drawing.Point(0, 0);
            this.Main.Name = "Main";
            this.Main.Size = new System.Drawing.Size(1065, 663);
            this.Main.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox1.ForeColor = System.Drawing.Color.White;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(0, 0);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(970, 585);
            this.listBox1.TabIndex = 2;
            // 
            // MessageTyper
            // 
            this.MessageTyper.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.MessageTyper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.MessageTyper.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MessageTyper.ForeColor = System.Drawing.Color.White;
            this.MessageTyper.Location = new System.Drawing.Point(38, 697);
            this.MessageTyper.Name = "MessageTyper";
            this.MessageTyper.Size = new System.Drawing.Size(743, 41);
            this.MessageTyper.TabIndex = 5;
            this.MessageTyper.Text = "";
            this.MessageTyper.TextChanged += new System.EventHandler(this.ResizeTextBox);
            this.MessageTyper.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EnterPressed);
            // 
            // focusControl
            // 
            this.focusControl.Enabled = true;
            this.focusControl.Interval = 10;
            this.focusControl.Tick += new System.EventHandler(this.focusControl_Tick);
            // 
            // addFriendPanel
            // 
            this.addFriendPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addFriendPanel.Controls.Add(this.CancelButton1);
            this.addFriendPanel.Controls.Add(this.ConnectFriendButton);
            this.addFriendPanel.Controls.Add(this.label4);
            this.addFriendPanel.Controls.Add(this.FriendCodeBox);
            this.addFriendPanel.Controls.Add(this.label3);
            this.addFriendPanel.Location = new System.Drawing.Point(323, 1590);
            this.addFriendPanel.Name = "addFriendPanel";
            this.addFriendPanel.Size = new System.Drawing.Size(414, 317);
            this.addFriendPanel.TabIndex = 2;
            // 
            // CancelButton1
            // 
            this.CancelButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.CancelButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CancelButton1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.CancelButton1.Location = new System.Drawing.Point(243, 279);
            this.CancelButton1.Name = "CancelButton1";
            this.CancelButton1.Size = new System.Drawing.Size(75, 23);
            this.CancelButton1.TabIndex = 4;
            this.CancelButton1.Text = "Cancel";
            this.CancelButton1.UseVisualStyleBackColor = false;
            this.CancelButton1.Click += new System.EventHandler(this.CancelButton1_Click);
            // 
            // ConnectFriendButton
            // 
            this.ConnectFriendButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ConnectFriendButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConnectFriendButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ConnectFriendButton.Location = new System.Drawing.Point(325, 279);
            this.ConnectFriendButton.Name = "ConnectFriendButton";
            this.ConnectFriendButton.Size = new System.Drawing.Size(75, 23);
            this.ConnectFriendButton.TabIndex = 3;
            this.ConnectFriendButton.Text = "Add";
            this.ConnectFriendButton.UseVisualStyleBackColor = false;
            this.ConnectFriendButton.Click += new System.EventHandler(this.ConnectFriendButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(145, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "Friendcode";
            // 
            // FriendCodeBox
            // 
            this.FriendCodeBox.Location = new System.Drawing.Point(129, 142);
            this.FriendCodeBox.Name = "FriendCodeBox";
            this.FriendCodeBox.Size = new System.Drawing.Size(141, 20);
            this.FriendCodeBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(27, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 31);
            this.label3.TabIndex = 0;
            this.label3.Text = "Add Friend";
            // 
            // NewUserPanel
            // 
            this.NewUserPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NewUserPanel.Controls.Add(this.MakeUser);
            this.NewUserPanel.Controls.Add(this.label7);
            this.NewUserPanel.Controls.Add(this.label6);
            this.NewUserPanel.Controls.Add(this.AddUsersPortBox);
            this.NewUserPanel.Controls.Add(this.AddUsersNameBox);
            this.NewUserPanel.Controls.Add(this.label5);
            this.NewUserPanel.Location = new System.Drawing.Point(3, 1000);
            this.NewUserPanel.Name = "NewUserPanel";
            this.NewUserPanel.Size = new System.Drawing.Size(1153, 750);
            this.NewUserPanel.TabIndex = 6;
            // 
            // MakeUser
            // 
            this.MakeUser.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.MakeUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.MakeUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MakeUser.ForeColor = System.Drawing.Color.White;
            this.MakeUser.Location = new System.Drawing.Point(1003, 709);
            this.MakeUser.Name = "MakeUser";
            this.MakeUser.Size = new System.Drawing.Size(91, 32);
            this.MakeUser.TabIndex = 7;
            this.MakeUser.Text = "Sign Me In!";
            this.MakeUser.UseVisualStyleBackColor = false;
            this.MakeUser.Click += new System.EventHandler(this.MakeUser_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(67, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(248, 25);
            this.label7.TabIndex = 4;
            this.label7.Text = "Port (Pick between 10 - 99)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(67, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 25);
            this.label6.TabIndex = 3;
            this.label6.Text = "Name";
            // 
            // AddUsersPortBox
            // 
            this.AddUsersPortBox.Location = new System.Drawing.Point(72, 188);
            this.AddUsersPortBox.Name = "AddUsersPortBox";
            this.AddUsersPortBox.Size = new System.Drawing.Size(158, 20);
            this.AddUsersPortBox.TabIndex = 2;
            // 
            // AddUsersNameBox
            // 
            this.AddUsersNameBox.Location = new System.Drawing.Point(72, 130);
            this.AddUsersNameBox.Name = "AddUsersNameBox";
            this.AddUsersNameBox.Size = new System.Drawing.Size(158, 20);
            this.AddUsersNameBox.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(18, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(261, 31);
            this.label5.TabIndex = 0;
            this.label5.Text = "Welcome New User!";
            // 
            // ToggleCode
            // 
            this.ToggleCode.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.ToggleCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ToggleCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ToggleCode.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ToggleCode.Location = new System.Drawing.Point(889, 699);
            this.ToggleCode.Name = "ToggleCode";
            this.ToggleCode.Size = new System.Drawing.Size(52, 37);
            this.ToggleCode.TabIndex = 7;
            this.ToggleCode.Text = "My Code";
            this.ToggleCode.UseVisualStyleBackColor = false;
            this.ToggleCode.Click += new System.EventHandler(this.ToggleCode_Click);
            // 
            // NotificationBox
            // 
            this.NotificationBox.Visible = true;
            this.NotificationBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.NotificationBox_MouseClick);
            // 
            // SignInPanel
            // 
            this.SignInPanel.Controls.Add(this.SignInButton);
            this.SignInPanel.Controls.Add(this.label10);
            this.SignInPanel.Controls.Add(this.label9);
            this.SignInPanel.Controls.Add(this.SignInPassword);
            this.SignInPanel.Controls.Add(this.SignInUsername);
            this.SignInPanel.Controls.Add(this.label8);
            this.SignInPanel.Location = new System.Drawing.Point(186, 81);
            this.SignInPanel.Name = "SignInPanel";
            this.SignInPanel.Size = new System.Drawing.Size(763, 523);
            this.SignInPanel.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(34, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 31);
            this.label8.TabIndex = 0;
            this.label8.Text = "Sign In";
            // 
            // SignInUsername
            // 
            this.SignInUsername.Location = new System.Drawing.Point(102, 121);
            this.SignInUsername.Name = "SignInUsername";
            this.SignInUsername.Size = new System.Drawing.Size(183, 20);
            this.SignInUsername.TabIndex = 1;
            // 
            // SignInPassword
            // 
            this.SignInPassword.Location = new System.Drawing.Point(102, 195);
            this.SignInPassword.Name = "SignInPassword";
            this.SignInPassword.Size = new System.Drawing.Size(183, 20);
            this.SignInPassword.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(102, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 25);
            this.label9.TabIndex = 3;
            this.label9.Text = "Username";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(102, 154);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 25);
            this.label10.TabIndex = 4;
            this.label10.Text = "Password";
            // 
            // SignInButton
            // 
            this.SignInButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.SignInButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SignInButton.ForeColor = System.Drawing.Color.White;
            this.SignInButton.Location = new System.Drawing.Point(680, 497);
            this.SignInButton.Name = "SignInButton";
            this.SignInButton.Size = new System.Drawing.Size(75, 23);
            this.SignInButton.TabIndex = 5;
            this.SignInButton.Text = "Sign In";
            this.SignInButton.UseVisualStyleBackColor = false;
            this.SignInButton.Click += new System.EventHandler(this.SignInButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1156, 750);
            this.Controls.Add(this.SignInPanel);
            this.Controls.Add(this.NewUserPanel);
            this.Controls.Add(this.ToggleCode);
            this.Controls.Add(this.addFriendPanel);
            this.Controls.Add(this.MessageTyper);
            this.Controls.Add(this.sendButton);
            this.Controls.Add(this.Menu);
            this.Controls.Add(this.Main);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Deactivate += new System.EventHandler(this.Form1_Deactivate);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Menu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AddFriendButton)).EndInit();
            this.Main.ResumeLayout(false);
            this.Main.PerformLayout();
            this.addFriendPanel.ResumeLayout(false);
            this.addFriendPanel.PerformLayout();
            this.NewUserPanel.ResumeLayout(false);
            this.NewUserPanel.PerformLayout();
            this.SignInPanel.ResumeLayout(false);
            this.SignInPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Menu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button sendButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel Main;
        private System.Windows.Forms.RichTextBox MessageTyper;
        private System.Windows.Forms.Timer focusControl;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox AddFriendButton;
        private System.Windows.Forms.Panel addFriendPanel;
        private System.Windows.Forms.TextBox FriendCodeBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ConnectFriendButton;
        private System.Windows.Forms.Panel NewUserPanel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox AddUsersPortBox;
        private System.Windows.Forms.TextBox AddUsersNameBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button MakeUser;
        private System.Windows.Forms.Button ToggleCode;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.NotifyIcon NotificationBox;
        private System.Windows.Forms.Button CancelButton1;
        private System.Windows.Forms.Panel SignInPanel;
        private System.Windows.Forms.Button SignInButton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox SignInPassword;
        private System.Windows.Forms.TextBox SignInUsername;
        private System.Windows.Forms.Label label8;
    }
}

